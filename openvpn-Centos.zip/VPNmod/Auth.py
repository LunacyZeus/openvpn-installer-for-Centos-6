#-*-coding:utf8;-*-
#qpy:2
#qpy:console

import os

if os.path.exists('/etc/openvpn/VPNmod/logs')==False:#日志目录不存在
  os.makedirs('/etc/openvpn/VPNmod/logs')


import json,httplib,urllib

import posix

import logging

logging.basicConfig(level=logging.DEBUG,
                format='%(asctime)s %(message)s',
                datefmt='%a,%Y %H:%M:%S',
                filename='/etc/openvpn/VPNmod/logs/Error.log',
                filemode='a')#载入日志系统


user=posix.environ['username']
passwd=posix.environ['password']


try:
	fp=open("config.json","r")
	JsonData=fp.read()
except:
	print "Config Error!"
	
config=json.loads(JsonData)


#user="SmallHo"
#passwd="123az"

url=config["Url"]#请求的地址
ServerCode=config["ServerCode"]#服务器代号

path="/UserLogin/?user={user}&passwd={passwd}&ServerCode={ServerCode}"#请求参数

path=path.format(user=user,passwd=passwd,ServerCode=config["ServerCode"])#载入

headers = {"Content-type": "application/x-www-form-urlencoded",
           "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
           'Accept-Language':'zh-CN,zh;q=0.8',
           'Cache-Control':'max-age=0',
           'Connection':'keep-alive',
           'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36'           
           }

conn = httplib.HTTPConnection(url)#建立一个连接

conn.request('GET', path, '', headers)#开始请求

httpres = conn.getresponse()#获取服务器响应

status=httpres.status#服务器响应码

#logging.debug('This is debug message')
#logging.info('This is info message')

if status==200:
  LoginStatus=httpres.read()#用户登录情况
  if LoginStatus=="0":#验证成功
    print '0'
  elif LoginStatus=="1":#验证失败
    logging.warning('Authorization failed: UserName: %s Password: %s'%(user,passwd))
    print '1'
  else:
    logging.info('Authorization failed: %s %s'%(status,url+path))
    print '2'
                
else:#服务器状态异常
  logging.warning('Server Error: %s %s'%(status,url+path))
  print "500"


conn.close()#断开连接
