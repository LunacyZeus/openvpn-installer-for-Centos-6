#!/bin/sh
#exit 0
result=$(python /etc/openvpn/VPNmod/Auth.py ${username} ${password})

exit $result
