#!/bin/bash
python /etc/openvpn/VPNmod/disconnect.py
