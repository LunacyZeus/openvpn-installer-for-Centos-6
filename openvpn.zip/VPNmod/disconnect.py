#-*-coding:utf8;-*-
#qpy:2
#qpy:console

import os
if os.path.exists('/etc/openvpn/VPNmod/logs')==False:#日志目录不存在
  os.makedirs('/etc/openvpn/VPNmod/logs')
  

import json,httplib,urllib

import posix

import logging

logging.basicConfig(level=logging.DEBUG,
                format='%(asctime)s %(message)s',
                datefmt='%a,%Y %H:%M:%S |',
                filename='/etc/openvpn/VPNmod/logs/Disconnect.log',
                filemode='a')#载入日志系统



user=posix.environ['common_name']
ip=posix.environ['trusted_ip']
bytes_sent=posix.environ['bytes_sent']
bytes_received=posix.environ['bytes_received']


try:
	fp=open("config.json","r")
	JsonData=fp.read()
except:
        logging.debug('Config Error!')
	
config=json.loads(JsonData)

#user="SmallHo"

url=config["Url"]#请求的地址
ServerCode=config["ServerCode"]#服务器代号

path="/Disconnect/?user={User}&bytes_received={bytes_received}&bytes_sent={bytes_sent}&remote_ip={ip}&ServerCode={ServerCode}"#请求参数
path=path.format(ServerCode=config["ServerCode"],RequestUrl=config["Url"],User=user,ip=ip,bytes_sent=bytes_sent,bytes_received=bytes_received)#组装请求


headers = {"Content-type": "application/x-www-form-urlencoded",
           "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
           'Accept-Language':'zh-CN,zh;q=0.8',
           'Cache-Control':'max-age=0',
           'Connection':'keep-alive',
           'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36'           
           }

conn = httplib.HTTPConnection(url)#建立一个连接

conn.request('GET', path, '', headers)#开始请求

httpres = conn.getresponse()#获取服务器响应

status=httpres.status#服务器响应码

#logging.debug('This is debug message')
#logging.info('This is info message')

if status==200:
  LoginStatus=httpres.read()#用户登录情况
  logging.info('Disconnect | %s | %s | %s | %s | (user,bytes_sent,bytes_received,ip)'%(user,bytes_sent,bytes_received,ip))
  print "Disconnect"
  
else:#服务器状态异常
  logging.warning('Server Error: %s %s'%(status,url+path))
  print "500"
                

conn.close()#断开连接
